import requests
import re
from bs4 import BeautifulSoup
from collections import namedtuple
import unicodedata
from html.parser import HTMLParser

DomMatch = namedtuple('DOMMatch', ['attrs', 'content'])
re_type = type(re.compile(''))

base_url = 'https://www.imdb.com/%s'
watchlist_url = 'user/ur%s/watchlist'
user_list_movies_url = 'list/%s/?view=detail&sort=%s&title_type=movie,short,video,tvShort,tvMovie,tvSpecial&start=1&page=%s'
user_list_tvshows_url = 'list/%s/?view=detail&sort=%s&title_type=tvSeries,tvMiniSeries&start=1&page=%s'
keywords_movies_url = 'search/keyword/?keywords=%s&sort=moviemeter,asc&title_type=movie,short,video,tvShort,tvMovie,tvSpecial&page=%s'
keywords_tvshows_url = 'search/keyword/?keywords=%s&sort=moviemeter,asc&title_type=tvSeries,tvMiniSeries&page=%s'
lists_link = 'user/ur%s/lists?tab=all&sort=mdfd&order=desc&filter=titles'
reviews_url = 'title/%s/reviews?sort=helpfulness'
trivia_url = 'title/%s/trivia'
blunders_url = 'title/%s/goofs'
parentsguide_url = 'title/%s/parentalguide'
images_url = 'title/%s/mediaindex?page=%s'
videos_url = '_json/video/%s'
keywords_url = 'title/%s/keywords?'
keywords_search_url = 'find?s=kw&q=%s'
people_images_url = 'name/%s/mediaindex?page=%s'
people_search_url_backup = 'search/name/?name=%s'
people_search_url = 'https://sg.media-imdb.com/suggests/%s/%s.json'
movie_year_check_url = 'https://v2.sg.media-imdb.com/suggestion/t/%s.json'
timeout = 20.0

def remove_accents(obj):
	try:
		try: obj = u'%s' % obj
		except: pass
		obj = ''.join(c for c in unicodedata.normalize('NFD', obj) if unicodedata.category(c) != 'Mn')
	except: pass
	return obj
  
def parseDOM(html, name='', attrs=None, ret=False):
	results = []
	try:
		if attrs: attrs = dict((key, re.compile(value + ('$' if value else ''))) for key, value in attrs.items())
		results = parse_dom(html, name, attrs, ret)
		if ret: results = [result.attrs[ret.lower()] for result in results]
		else: results = [result.content for result in results]
	except: pass
	return results

def __get_dom_content(html, name, match):
	result = ''
	try:
		if match.endswith('/>'): return ''
		tag = re.match(r'<([^\s/>]+)', match)
		if tag: name = tag.group(1)
		start_str = '<%s' % name
		end_str = '</%s' % name
		start = html.find(match)
		end = html.find(end_str, start)
		pos = html.find(start_str, start + 1)
		while pos < end and pos != -1:
			tend = html.find(end_str, end + len(end_str))
			if tend != -1:
				end = tend
			pos = html.find(start_str, pos + 1)
		if start == -1 and end == -1: result = ''
		elif start > -1 and end > -1: result = html[start + len(match):end]
		elif end > -1: result = html[:end]
		elif start > -1: result = html[start + len(match):]
		else: result = ''
		return result
	except: pass
	return result

def __get_dom_elements(item, name, attrs):
	this_list = []
	try:
		if not attrs:
			pattern = r'(<%s(?:\s[^>]*>|/?>))' % name
			this_list = re.findall(pattern, item, re.M | re.S | re.I)
		else:
			last_list = None
			for key, value in attrs.items():
				value_is_regex = isinstance(value, re_type)
				value_is_str = isinstance(value, str)
				pattern = r'''(<{tag}[^>]*\s{key}=(?P<delim>['"])(.*?)(?P=delim)[^>]*>)'''.format(tag=name, key=key)
				re_list = re.findall(pattern, item, re.M | re.S | re.I)
				if value_is_regex:
					this_list = [r[0] for r in re_list if re.match(value, r[2])]
				else:
					temp_value = [value] if value_is_str else value
					this_list = [r[0] for r in re_list if set(temp_value) <= set(r[2].split(' '))]
				if not this_list:
					has_space = (value_is_regex and ' ' in value.pattern) or (value_is_str and ' ' in value)
					if not has_space:
						pattern = r'''(<{tag}[^>]*\s{key}=((?:[^\s>]|/>)*)[^>]*>)'''.format(tag=name, key=key)
						re_list = re.findall(pattern, item, re.M | re.S | re.I)
						if value_is_regex:
							this_list = [r[0] for r in re_list if re.match(value, r[1])]
						else:
							this_list = [r[0] for r in re_list if value == r[1]]
				if last_list is None:
					last_list = this_list
				else:
					last_list = [item for item in this_list if item in last_list]
			this_list = last_list
	except: pass
	return this_list

def __get_attribs(element):
	attribs = {}
	try:
		for match in re.finditer(r'''\s+(?P<key>[^=]+)=\s*(?:(?P<delim>["'])(?P<value1>.*?)(?P=delim)|(?P<value2>[^"'][^>\s]*))''', element):
			match = match.groupdict()
			value1 = match.get('value1')
			value2 = match.get('value2')
			value = value1 if value1 is not None else value2
			if value is None: continue
			attribs[match['key'].lower().strip()] = value
	except: pass
	return attribs

def parse_dom(html, name='', attrs=None, req=False, exclude_comments=False):
	all_results = []
	try:
		if attrs is None: attrs = {}
		name = name.strip()
		if isinstance(html, str) or isinstance(html, DomMatch): html = [html]
		elif not isinstance(html, list): return ''
		if not name: return ''
		if not isinstance(attrs, dict): return ''
		if req:
			if not isinstance(req, list): req = [req]
			req = set([key.lower() for key in req])
		for item in html:
			if isinstance(item, DomMatch): item = item.content
			if exclude_comments: item = re.sub(re.compile(r'<!--.*?-->', re.S), '', item)
			results = []
			for element in __get_dom_elements(item, name, attrs):
				attribs = __get_attribs(element)
				if req and not req <= set(attribs.keys()): continue
				temp = __get_dom_content(item, name, element).strip()
				results.append(DomMatch(attribs, temp))
				item = item[item.find(temp, item.find(element)):]
			all_results += results
	except: pass
	return all_results
  
def make_session(url='https://'):
	session = requests.Session()
	session.mount(url, requests.adapters.HTTPAdapter(pool_maxsize=100))
	return session	
  
session = make_session()

def kimscrap(media_name:str):
    #Search for the 1st match

    base_url = "https://kids-in-mind.com/search-desktop.htm?fwp_keyword="

    search_url = base_url+media_name.lower().replace(" ","+")
    r = requests.get(search_url)
    #print(search_url)
    soup = BeautifulSoup(r.content,"html.parser") 
    match = soup.find("div",{"class":"fwpl-item el-2onu0j search-result"}).find("a")["href"]
    print('Match result for movie: '+ media_name.lower()+ ' was found\n' +match)
    #Call Scrapper getDesc
    response = {}
    response = getDesc(match)
    return response

def getDesc(url:str):
    r = requests.get(url)
    soup = BeautifulSoup(r.content, "html.parser") 
      
    #Get Rating Out of 5
    rating = soup.find("span", {"style" : "font-size:14px !important"}).text

    #Get Category Desc
    NudityDesc = soup.find("h2", {"id" : "sex"}).find_next_sibling("p").text.replace("\xa0","").replace("\n►","\n").replace("_"," ")
    ViolenceDesc = soup.find("h2", {"id" : "violence"}).find_next_sibling("p").text.replace("\xa0","").replace("\n►","\n").replace("_"," ")
    LanguageDesc = soup.find("h2", {"id" : "language"}).find_next_sibling("p").text.replace("\xa0","").replace("\n►","\n").replace("_"," ")

    #Save Responses to Dict
    Response = {}
    Response['NudityRate'] = rating[len(rating)-5]
    Response['ViolenceRate'] = rating[len(rating)-3] 
    Response['LanguageRate'] = rating[len(rating)-1] 
    Response['Nudity'] = NudityDesc
    Response['Violence'] = ViolenceDesc
    Response['Language'] = LanguageDesc
    return Response


def replace_html_codes(txt):
	txt = re.sub(r"(&#[0-9]+)([^;^0-9]+)", "\\1;\\2", txt)
	txt = HTMLParser().unescape(txt)
	#txt = HTMLParser().unescape()
	txt = txt.replace("&quot;", "\"")
	txt = txt.replace("&amp;", "&")
	return txt
  
def get_imdb2(url, action):
	imdb_list = []
	#action = params['action']
	#url = params['url']
	next_page = None
	if action == 'imdb_parentsguide':
		spoiler_results = None
		spoiler_list = []
		spoiler_append = spoiler_list.append
		imdb_append = imdb_list.append
		result = session.get(url, timeout=timeout)
		result = result.text
		result = result.replace('\n', ' ')
		results = parseDOM(result, 'section', attrs={'id': r'advisory-(.+?)'})
		print(results)
		try: spoiler_results = parseDOM(result, 'section', attrs={'id': 'advisory-spoilers'})[0]
		except: pass
		if spoiler_results:
			results = [i for i in results if not i in spoiler_results]
			spoiler_results = spoiler_results.split('<h4 class="ipl-list-title">')[1:]
			for item in spoiler_results:
				item_dict = {}
				try:
					title = replace_html_codes(re.findall(r'(.+?)</h4>', item, re.DOTALL)[0])
					item_dict['title'] = title
				except: continue
				try:
					listings = parseDOM(item, 'li', attrs={'class': 'ipl-zebra-list__item'})
					item_dict['listings'] = []
				except: continue
				dict_listings_append = item_dict['listings'].append
				for item in listings:
					try:
						listing = replace_html_codes(re.findall(r'(.+?)     <div class="', item, re.DOTALL)[0])
						if not listing in item_dict['listings']: dict_listings_append(listing)
					except: pass
				if not item_dict in spoiler_list: spoiler_append(item_dict)
		for item in results:
			item_dict = {}
			try:
				title = replace_html_codes(parseDOM(item, 'h4', attrs={'class': 'ipl-list-title'})[0])
				item_dict['title'] = title
			except: continue
			try:
				ranking = replace_html_codes(parseDOM(item, 'span', attrs={'class': 'ipl-status-pill ipl-status-pill--(.+?)'})[0])
				item_dict['ranking'] = ranking
			except: continue
			try:
				listings = parseDOM(item, 'li', attrs={'class': 'ipl-zebra-list__item'})
				item_dict['listings'] = []
			except: continue
			dict_listings_append = item_dict['listings'].append
			for item in listings:
				try:
					listing = replace_html_codes(re.findall(r'(.+?)     <div class="', item, re.DOTALL)[0])
					if not listing in item_dict['listings']: dict_listings_append(listing)
				except: pass
			if item_dict: imdb_append(item_dict)
		if spoiler_list:
			for imdb in imdb_list:
				for spo in spoiler_list:
					if spo['title'] == imdb['title']:
						imdb['listings'].extend(spo['listings'])
		for item in imdb_list:
			item['listings'] = list(set(item['listings']))
	return (imdb_list, next_page)


def get_imdb(params):
	imdb_list = []
	action = params['action']
	url = params['url']
	next_page = None
	if 'date' in params:
		from datetime import datetime, timedelta
		date_time = (datetime.utcnow() - timedelta(hours=5))
		for i in re.findall(r'date\[(\d+)\]', url):
			url = url.replace('date[%s]' % i, (date_time - timedelta(days = int(i))).strftime('%Y-%m-%d'))
	if action in ('imdb_watchlist', 'imdb_user_list_contents', 'imdb_keywords_list_contents'):
		def _process():
			for item in items:
				try:
					title = parseDOM(item, 'a')[1]
					year = parseDOM(item, 'span', attrs={'class': 'lister-item-year.+?'})
					year = re.findall(r'(\d{4})', year[0])[0]
					imdb_id = parseDOM(item, 'a', ret='href')[0]
					imdb_id = re.findall(r'(tt\d*)', imdb_id)[0]
					yield {'title': str(title), 'year': str(year), 'imdb_id': str(imdb_id)}
				except: pass
		if action in ('imdb_watchlist', 'imdb_user_list_contents'):
			list_url_type = user_list_movies_url if params['media_type'] == 'movie' else user_list_tvshows_url
			if action == 'imdb_watchlist':
				url = parseDOM(remove_accents(session.get(url, timeout=timeout).text), 'meta', ret='content', attrs = {'property': 'pageId'})[0]
			url = base_url % list_url_type % (url, params['sort'], params['page_no'])
		result = session.get(url, timeout=timeout)
		result = remove_accents(result.text)
		result = result.replace('\n', ' ')
		items = parseDOM(result, 'div', attrs={'class': '.+? lister-item'})
		items += parseDOM(result, 'div', attrs={'class': 'lister-item .+?'})
		items += parseDOM(result, 'div', attrs={'class': 'list_item.+?'})
		imdb_list = list(_process())
		try:
			result = result.replace('"class="lister-page-next', '" class="lister-page-next')
			next_page = parseDOM(result, 'a', ret='href', attrs={'class': '.*?lister-page-next.*?'})
			if len(next_page) == 0:
				next_page = parseDOM(result, 'div', attrs = {'class': 'pagination'})[0]
				next_page = zip(parseDOM(next_page, 'a', ret='href'), parseDOM(next_page, 'a'))
				next_page = [i[0] for i in next_page if 'Next' in i[1]]
		except: pass
	elif action == 'imdb_user_lists':
		def _process():
			for item in items:
				try:
					title = parseDOM(item, 'a')[0]
					title = replace_html_codes(title)
					url = parseDOM(item, 'a', ret='href')[0]
					list_id = url.split('/list/', 1)[-1].strip('/')
					yield {'title': title, 'list_id': list_id}
				except: pass
		result = session.get(url, timeout=timeout)
		result = remove_accents(result.text)
		items = parseDOM(result, 'li', attrs={'class': 'ipl-zebra-list__item user-list'})
		imdb_list = list(_process())
	elif action in ('imdb_trivia', 'imdb_blunders'):
		def _process():
			for item in items:
				try:
					content = re.sub(r'<a href="\S+">', '', item).replace('</a>', '')
					content = replace_html_codes(content)
					content = content.replace('<br/><br/>', '\n')
					yield content
				except: pass
		result = session.get(url, timeout=timeout)
		result = remove_accents(result.text)
		result = result.replace('\n', ' ')
		items = parseDOM(result, 'div', attrs={'class': 'sodatext'})
		imdb_list = list(_process())
	elif action == 'imdb_reviews':
		def _process():
			for listing in all_reviews:
				try: spoiler = listing['spoiler']
				except: spoiler = False
				try: listing = listing['content']
				except: continue
				try:
					try:
						title = parseDOM(listing, 'a', attrs={'class': 'title'})[0]
					except: title = ''
					try:
						date = parseDOM(listing, 'span', attrs={'class': 'review-date'})[0]
					except: date = ''
					try:
						rating = parseDOM(listing, 'span', attrs={'class': 'rating-other-user-rating'})
						rating = parseDOM(rating, 'span')
						rating = rating[0] + rating[1]
					except: rating = ''			
					try:
						content = parseDOM(listing, 'div', attrs={'class': 'text show-more__control'})[0]
						content = replace_html_codes(content)
						content = content.replace('<br/><br/>', '\n')
					except: continue
					review = {'spoiler': spoiler, 'title': title, 'date': date, 'rating': rating, 'content': content}
					yield review
				except: pass
		result = session.get(url, timeout=timeout)
		result = remove_accents(result.text)
		result = result.replace('\n', ' ')
		non_spoilers = parseDOM(result, 'div', attrs={'class': 'lister-item mode-detail imdb-user-review  collapsable'})
		spoilers = parseDOM(result, 'div', attrs={'class': 'lister-item mode-detail imdb-user-review  with-spoiler'})
		non_spoilers = [{'spoiler': False, 'content': i} for i in non_spoilers]
		spoilers = [{'spoiler': True, 'content': i} for i in spoilers]
		all_reviews = non_spoilers + spoilers
		imdb_list = list(_process())
	elif action == 'imdb_images':
		def _process():
			for item in image_results:
				try:
					try: title = re.findall(r'alt="(.+?)"', item, re.DOTALL)[0]
					except: title = ''
					try:
						thumb = re.findall(r'src="(.+?)"', item, re.DOTALL)[0]
						split = thumb.split('_V1_')[0]
						thumb = split + '_V1_UY300_CR26,0,300,300_AL_.jpg'
						image = split + '_V1_.jpg'
						images = {'title': title, 'thumb': thumb, 'image': image}
					except: continue
					yield images
				except: pass
		image_results = []
		result = session.get(url, timeout=timeout)
		result = remove_accents(result.text)
		result = result.replace('\n', ' ')
		try:
			pages = parseDOM(result, 'span', attrs={'class': 'page_list'})[0]
			pages = [int(i) for i in parseDOM(pages, 'a')]
		except: pages = [1]
		if params['next_page'] in pages:
			next_page = params['next_page']
		try:
			image_results = parseDOM(result, 'div', attrs={'class': 'media_index_thumb_list'})[0]
			image_results = parseDOM(image_results, 'a')
		except: pass
		if image_results: imdb_list = list(_process())
	elif action == 'imdb_videos':
		def _process():
			for item in playlists:
				videos = []
				vid_id = item['videoId']
				metadata = videoMetadata[vid_id]
				title = metadata['title']
				poster = metadata['slate']['url']
				for i in metadata['encodings']:
					quality = i['definition']
					if quality == 'auto': continue
					if quality == 'SD': quality = '360p'
					quality_rank = quality_ranks_dict[quality]
					videos.append({'quality': quality, 'quality_rank': quality_rank, 'url': i['videoUrl']})
				yield {'title': title, 'poster': poster, 'videos': videos}
		quality_ranks_dict = {'360p': 3, '480p': 2, '720p': 1, '1080p': 0}
		result = session.get(url, timeout=timeout).json()
		playlists = result['playlists'][params['imdb_id']]['listItems']
		videoMetadata = result['videoMetadata']
		imdb_list = list(_process())
	elif action == 'imdb_people_id':
		try:
			import json
			name = params['name']
			result = session.get(url, timeout=timeout).content
			result = json.loads(result.replace('imdb$%s(' % name.replace(' ', '_'), '')[:-1])['d']
			imdb_list = [i['id'] for i in result if i['id'].startswith('nm') and i['l'].lower() == name][0]
		except: pass
		if not imdb_list:
			result = session.get(params['url_backup'], timeout=timeout)
			result = remove_accents(result.text)
			result = result.replace('\n', ' ')
			try:
				result = parseDOM(result, 'div', attrs={'class': 'lister-item-image'})[0]
				imdb_list = re.findall(r'href="/name/(.+?)"', result, re.DOTALL)[0]
			except: pass
	elif action == 'imdb_movie_year':
		result = session.get(url, timeout=timeout).json()
		try:
			result = result['d'][0]
			imdb_list = str(result['y'])
		except: pass
	elif action == 'imdb_parentsguide':
		spoiler_results = None
		spoiler_list = []
		spoiler_append = spoiler_list.append
		imdb_append = imdb_list.append
		result = session.get(url, timeout=timeout)
		result = result.text
		result = result.replace('\n', ' ')
		results = parseDOM(result, 'section', attrs={'id': r'advisory-(.+?)'})
		try: spoiler_results = parseDOM(result, 'section', attrs={'id': 'advisory-spoilers'})[0]
		except: pass
		if spoiler_results:
			results = [i for i in results if not i in spoiler_results]
			spoiler_results = spoiler_results.split('<h4 class="ipl-list-title">')[1:]
			for item in spoiler_results:
				item_dict = {}
				try:
					title = replace_html_codes(re.findall(r'(.+?)</h4>', item, re.DOTALL)[0])
					item_dict['title'] = title
				except: continue
				try:
					listings = parseDOM(item, 'li', attrs={'class': 'ipl-zebra-list__item'})
					item_dict['listings'] = []
				except: continue
				dict_listings_append = item_dict['listings'].append
				for item in listings:
					try:
						listing = replace_html_codes(re.findall(r'(.+?)     <div class="', item, re.DOTALL)[0])
						if not listing in item_dict['listings']: dict_listings_append(listing)
					except: pass
				if not item_dict in spoiler_list: spoiler_append(item_dict)
		j=0
		for item in results:
			
			item_dict = {}
			try:
				title = replace_html_codes(parseDOM(item, 'h4', attrs={'class': 'ipl-list-title'})[0])
				item_dict['title'] = title
			except: continue
			
			#addition
			try:
				ranking = replace_html_codes(parseDOM(item, 'span', attrs={'class': 'ipl-status-pill '})[0])
				# if ranking is not None : item_dict['ranking'] = ranking
				# if ranking != None : item_dict['ranking'] = ranking
				# if ranking is not "" : item_dict['ranking'] = ranking
				# if ranking is not " " : item_dict['ranking'] = ranking
				# if ranking !="" : item_dict['ranking'] = ranking
				# if ranking !=" " : item_dict['ranking'] = ranking
				if ranking in ['None','Mild','Moderate','Severe']: item_dict['ranking'] = ranking
				else: 			
					ranking = replace_html_codes(parseDOM(item, 'span', attrs={'class': 'ipl-status-pill ipl-status-pill--(.+?)'})[0])
					item_dict['ranking'] = ranking
			except: continue
			#votes
			try:
				votes = replace_html_codes(parseDOM(item, 'a', attrs={'class': 'advisory-severity-vote__message'})[0])
				substring = 'found this'
				if substring in votes:
					item_dict['votes'] = votes
			except: continue
			
			
			
			try:
				listings = parseDOM(item, 'li', attrs={'class': 'ipl-zebra-list__item'})
				item_dict['listings'] = []
			except: continue
			dict_listings_append = item_dict['listings'].append
			for item in listings:
				try:
					listing = replace_html_codes(re.findall(r'(.+?)     <div class="', item, re.DOTALL)[0])
					if not listing in item_dict['listings']: dict_listings_append(listing)
				except: pass
			if item_dict: imdb_append(item_dict)
		j = j+1
		
		if spoiler_list:
			for imdb in imdb_list:
				for spo in spoiler_list:
					if spo['title'] == imdb['title']:
						imdb['listings'].extend(spo['listings'])
		for item in imdb_list:
			item['listings'] = list(set(item['listings']))
	elif action == 'imdb_keywords':
		def _process():
			for item in items:
				try:
					keyword = re.findall(r'" >(.+?)</a>', item, re.DOTALL)[0]
					yield keyword
				except: pass
		result = session.get(url, timeout=timeout)
		result = remove_accents(result.text)
		result = result.replace('\n', ' ')
		items = parseDOM(result, 'div', attrs={'class': 'sodatext'})
		imdb_list = list(_process())
		imdb_list = sorted(imdb_list)
	elif action == 'imdb_keyword_search':
		def _process():
			for item in items:
				try:
					keyword = re.findall(r'keywords=(.+?)"', item, re.DOTALL)[0]
					listings = re.findall(r'</a> (.+?) </td>', item, re.DOTALL)[0]
					yield (keyword, listings)
				except: pass
		result = session.get(url, timeout=timeout)
		result = remove_accents(result.text)
		result = result.replace('\n', ' ')
		items_odd = parseDOM(result, 'tr', attrs={'class': 'findResult odd'})
		items_even = parseDOM(result, 'tr', attrs={'class': 'findResult even'})
		items = [x for y in zip(items_odd, items_even) for x in y]
		imdb_list = list(_process())
	return (imdb_list, next_page)


def imdb_parentsguide(imdb_id):
	url = base_url % parentsguide_url % imdb_id
	#string = 'imdb_parentsguide_%s' % imdb_id
	params2 = {'url': url, 'action': 'imdb_parentsguide'}
	return get_imdb(params2)
	# Desc = get_imdb(params2)
	# CatCount = len(Desc[0])
	# i = 0
	# for i in range(0,CatCount):
	  # item = Desc[0][i]
	  # print("name: " + item['title'])
	  # print("score: " + item['ranking'])
	  # listingitem = item['listings']
	  # x = 1
	  # print("description: ")
	  # for item in listingitem:
		# print(str(x)+ "- " + item.strip())
		# print()
		# x = x +1
	# return details
  
# media_name = "The northman"
# imdb_id = 'tt1649418'
# Desc = {}
# #Desc = kimscrap(media_name)
# Desc = imdb_parentsguide(imdb_id)

# CatCount = len(Desc[0])
# i = 0
# for i in range(0,CatCount):
  # item = Desc[0][i]
  # print("Category: " + item['title'])
  # print("Ranking: " + item['ranking'])
  # listingitem = item['listings']
  # x = 1
  # print("Listings: ")
  # for item in listingitem:
    # print(str(x)+ "- " + item.strip())
    # print()
    # x = x +1
