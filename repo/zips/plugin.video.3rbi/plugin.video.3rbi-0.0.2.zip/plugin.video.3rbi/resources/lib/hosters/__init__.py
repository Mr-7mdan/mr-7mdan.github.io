# -*- coding: utf-8 -*-
"""
Hoster Resolvers Package
Each resolver is in its own file for better organization
"""
